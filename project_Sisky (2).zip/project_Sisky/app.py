from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from models import db, User  # Импорт модели User из models.py

# Создаем приложение Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'your_secret_key'

# Подключаем базу данных и шифрование
db.init_app(app)
bcrypt = Bcrypt(app)

# Главная страница
@app.route('/')
def index():
    return render_template('index.html')  # Показываем главную страницу

# Промежуточная страница после регистрации
@app.route('/success')
def success():
    return render_template('success.html')

# Регистрация
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')

        # Проверка на существующего пользователя с таким именем или email
        existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
        if existing_user:
            flash('Пользователь с таким именем или email уже существует!', 'error')  # Сообщение об ошибке
            return redirect(url_for('register'))

        # Если пользователя нет, создаем нового
        new_user = User(username=username, email=email, password=password)
        db.session.add(new_user)
        db.session.commit()

        flash('Ура! Вы зарегистрировались!', 'success')  # Сообщение об успехе
        return redirect(url_for('success'))

    return render_template('register.html')

# Отображение пользователей
@app.route('/users')
def users():
    all_users = User.query.all()
    return render_template('users.html', users=all_users)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Создает таблицы, если их нет
    app.run(debug=True)
